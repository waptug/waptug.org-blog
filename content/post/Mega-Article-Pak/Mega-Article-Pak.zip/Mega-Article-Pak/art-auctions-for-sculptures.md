---
title: "Art Auctions For Sculptures"
date: 2024-11-30T12:00:34-08:00
description: "Art Auctions Tips for Web Success"
featured_image: "/images/Art Auctions.jpg"
tags: ["Art Auctions"]
---

Art Auctions For Sculptures 

Art auctions for sculptures are a great way to find new art for your home or office.  I like to peruse the online auction sites for nice sculptures.  I have found some very interesting items when I’ve looked.

There was a sculpture sold on eBay recently that was entitled Love.  The art auction for this sculpture went above the estimated value.  The piece was red and blue and made of polychrome aluminum.  The French artist’s name was Robert Indiana.  The art auction listed the item as six feet tall, six feet wide and three feet deep.

I liked a hall stand that was carved from wood that I found in an online art auction.  The carving depicted a playful bear climbing a fir tree.  There was a young bear cub carved into one of the branches.  The branches were there to serve as garment hooks and there was even a mirror on the piece in a carved oak leaf designed frame.

There was an exquisite sculpture by a Russian artist that was sold recently in an art auction.  The subject of the sculpture was a Bar Mitzvah boy and the medium was marble.  I think that marble statues seem so timeless and elegant.  It is an excellent medium for a sculpture.

The wife of artist Yitzhak Danziger signed a certificate for the brass sculpture her husband completed in 1969.  Danziger is an Israeli artist.  The piece looked very abstract to me.  It did not do very well in the art auction and sold for less than it’s estimated worth.

I found a lot of bronze sculptures in the online art auctions.  Most of them were of people, but the ones I liked best were abstract.  My absolute favorite was a Harry Bertoia bronze sculpture called Bush.  This piece is also known as a Brain or Coral.  The bidding for this piece of art in the art auction was started at thirty nine thousand dollars.  It didn’t get a bidder.

I saw little interest in the bronze sculpture art auctions for animal figures.  I’m not sure if the reasons they didn’t get bidders were because of subject matter or because of price.  Bronze is an expensive medium for an artist to work in and it takes a lot of training to be proficient.

I have a favorite glass sculptor.  His work goes for so much in online art auctions that I will probably never own a piece of his work.  Dale Chihuly is magnificent.  There are permanent installations of his tremendous work all over the world.

Crystal sculptures look more like paperweights to me.  Online art auctions for glass representations of animals and sea life are really neat.  My favorite art auction recently was for a hand blown glass jellyfish.  It was magical.

I liked another online art auction for optical crystal that had been turned into a work of art by artist Christopher Ries.  The piece was small and called Lotus.  It would look so pretty in a well lit display case.

I’m jealous of the buyer that gets to call this sculpture their own.  They won the piece in the art auction for just under a thousand dollars.  This artist uses blocks of pure, clear lead crystal cast from Schott Glass Technologies of Duryea, Pennsylvania.  It is truly amazing art.  His work is prominently displayed in numerous galleries and even in the Columbus airport in Columbus, Ohio.

PPPPP

568

