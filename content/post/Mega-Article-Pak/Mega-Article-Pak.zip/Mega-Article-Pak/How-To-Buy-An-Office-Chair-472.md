---
title: "How To Buy An Office Chair"
date: 2019-10-01T03:10:00-08:00
description: "Office Chairs Tips for Web Success"
featured_image: "/images/Office Chairs.jpg"
tags: ["Office Chairs"]
---

How To Buy An Office Chair

Everyone knows that people come in many different shapes 
and sizes.  Before buying an office chair, there are a 
few questions that you should ask yourself.  You should
decide how you plan to use the chair, as this will be 
the determining factor for true comfort.  Almost all 
office ahirs come with a variety of mechanisms that will
control the tilting angle, tension tightness, and a 
mixture of other controls as well.

Heavy use chair
These types of chairs are for those who plan to sitting
at their desk for long periods of time.  If this is your
profession, you should look for a chair with a tilting 
mechanism and also a fatigue reducing device on the 
bottom of the chair seat.  Because of this device, moving
forward or backward will enable the chair move with you
in order to provide support.  This will help to support 
your back at all times.

Moderate use chair
If you are a typical assistant manager or run back and
forth between your desk and other areas throughout the
day, you should consider getting an office chair with a
knee-tilt mechanism.  This allows you to lean back in the 
chair, yet still keep your feet firmly planted on the 
ground.  Chairs that don't have this will typically lift
your feet when you lean back and fort, which can 
ultimately lead to discomfort over time.  Best of all, 
these chairs are normally more stylish than the average
task chair.

Executive office chair
These types of office chairs normally have the same types
of mechanical features as moderate use chairs, although 
they are normally larger, more comfortable, and offer
more style for the executive.  They are designed for 
the average executive who is busy running about and spends
a good deal of time either on the phone or on a computer.
Comfort, style, and status are the key features when 
buying one of these types of office chairs.

For the average security, an office chair that offers 
the ultimate in comfort is an ideal purchase.  You can 
purchase a heavy use chair, as you'll probably spend a
good amount of time at a desk.  If you move around a 
bit, you may want to go with a moderate use chair, as it
will provide the comfort you need when you return back
to your desk.

General rules of the office chair.
1.  You should make sure your feet rest comfortably on 
the floor, and your thighs should be fully supported and
placed square on the floor.
2.  Your back should be supported comfortably.  The angle
that's formed by your upper legs and torso should be
between 90 and 105 degrees.
3.  When you tilt back it should be easy, although it 
shouldn't be too easy.
4.  The desk chair should be customized to permit frequent
changes in posture.

(word count 472)

PPPPP
