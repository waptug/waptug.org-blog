---
title: "After school activities for the overweight"
date: 2024-03-21T19:34:18-08:00
description: "After School Activities Tips for Web Success"
featured_image: "/images/After School Activities.jpg"
tags: ["After School Activities"]
---

After school activities for the overweight

Research and studies show that our children are growing fater by the
day. Many families all over America are struggling to keep the weight of 
their children within reasonable limits. As a parent, I know that it's 
nearly impossible for me to look into the tear-filled eyes of my son and 
refuse food. 

So, what's the alternative? Studies show that the number one reason for 
obesity in children is not junk food and colas. It's actually TV.  
Children tend to plop themselves on the sofa and munch away happily when 
they are in front of the TV sets. But, once the set is off, their natural 
buoyancy will lead the children to do stuff and to move their body. THey will then be diverted from eating.

Recreational after school activities are a must if you feel that your 
child is beginning to put on undesirable fat. It is better to begin these 
activities as early as possible. The more weight the child gains, the 
harder he has to work to shed it. Football, swimming, skating and Karate 
are just some activities he can participate in. Structured and disciplined 
exercise is possible only when one is put into a formal environment. That 
is why an overweight child simply HAS to be put into an after school 
program of this kind. 

(word count 219)

PPPPP
