---
title: "Saving Kuwait"
date: 2022-04-06T22:10:31-08:00
description: "TXT Tips for Web Success"
featured_image: "/images/TXT.jpg"
tags: ["TXT"]
---

Saving Kuwait

The history of American use of its military forces, there are some stand out examples of how America considers its military might be a force for good and justice.  And the use of military for a just cause can be beautifully illustrated in the way America came to the aid of an ally in the Gulf War of 1991.  This war goes under a lot of names including Operation Desert Storm and the Liberation of Kuwait.  But whatever title, it was a battle America needed to enter into because of an unjust invasion of an ally and an act of aggression we could not just stand by and let happen.

The United States and the civilized nations of the world had put up with a lot of barbaric behavior from Saddam Husain, the dictator in Iraq for a long time.  He was becoming more and more aggressive in his push to test the will and the ability of advanced nations to stop him.  But he crossed the line when on August 2, 1990 Iraq invaded and occupied Kuwait on trumped up charges of illegal drilling of oil on border property between the two countries.

It is important to remember that America and it’s allies did not launch a full scale attack within days or weeks of the Iraqi take over of Kuwait.  There were efforts to negotiate and resolve the crisis by peaceful means.  But Saddam Hussein defied the world and continued his plan to absorb Kuwait and then possibly take the attack to the next stage into Saudi Arabia.

The Gulf War was also an important statement to the world that America’s allies are important to us and we will defend them if it comes to that.  We proved that in World War II, Korea, Vietnam and here in the Middle East.  When a country becomes a friend of the United States, it’s enemies become our enemies.  And in this unthinkable invasion, not only did Iraq directly assault one of America’s allies, that hostility showed that Saudi Arabia was at risk which was a very important ally as well.

America also leveraged its ability to depend on it’s friends from around the world, rallying a tremendous international force as the preparations for war began to mature.  In total, 34 countries sent troops, ships, arms and other military assistance to join with American military power to turn back this invasion.

The other lesson this war taught the enemies of America is the phenomenal effectiveness of the American military.  On January 17, 1991, the assault began with a massive air attack that stunned the Iraqis and the world.  The ferocity of the bombings and the firestorm that defying the west brought down on the Iraqi military virtually doomed them to ever mount an efficient force to fight back against this overwhelming military response to their aggression.  

Following that air attack came one of the most brilliant ground campaigns in modern warfare.  Using modern technology, America faced Iraq’s impressive army on their home turf and soundly defeated them.  The Iraqi strategy was to keep the massive desert behind them because they felt no enemy could ever navigate that desert and find their rear flank.  But was a deadly miscalculation as the coalition forces, lead by General Norman Schwarzkopf, used satellite technology and navigation systems to guide their armies across that desert by night and stage a stunning surprise attack on the Iraqi Republican Guard bringing them to defeat with a decisive blow.

The term “Lightning War” could best be used to describe the l ability of the American lead coalition armies to repel this invasion on Kuwait.  By early March of 1991, major hostilities were over and Kuwait had been liberated.  To defeat an enemy in less than 90 days was accomplishment the world never thought possible.  But demonstrated to the world that America was able to defend its allies and stop a ruthless dictator.

Since that war there has been discussions about whether President Bush should have used the advantage we gained by defeating Saddam’s armies to capture Iraq as well.  President Bush showed great wisdom by sticking to the declared mission and returning Kuwait to Kuwaiti control.  H shows that President Bush in 1991 was showing wisdom in his leadership which resulted in Operation Desert Storm turning out to be one of the most successful military campaigns in United States history.

PPPPP 735

