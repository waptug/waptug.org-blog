---
title: "Save Money when you Purchase Damaged Goods"
date: 2023-05-20T20:12:12-08:00
description: "txt Tips for Web Success"
featured_image: "/images/txt.jpg"
tags: ["txt"]
---

Save Money when you Purchase Damaged Goods

No one wants to get any item they have purchased home and discover that it has been damaged in some way. In the event that it does happen the course of action to follow is to return it to the place of purchase for another product in excellent condition or for a refund of the cost they paid for it. However, the retailer has to try to make some money of these damaged goods so they will sell then at a cost that is much less than the actual cost of the item.

If you are handy with repairs, then this could be a great way for you to get a bargain price on the products you really want. Furniture is a very common type of product that can be damaged. Yet it is fairly easy to repair a torn cushion or cover up scratches on tables and desks. The more severe damage the item has then the more money you will save on the cost. It is a very good idea to take find out exactly what repairs are involved and the cost of the materials to complete the job. If you won’t be able to complete the work on your own then you need to find out how much it will cost to take it to someone else. 

The majority of retailers don’t leave these returned items with scratches or dents in them out for everyone to see. It is definitely worth the time to ask the sales clerk if there are any damaged items of a particular product that you may be able to purchase at a lower price. I did this at Sears once with a TV and got exactly what I wanted for $600 less because there was a huge scratch on the top of it. I was able to fill it in with some Old English Polish and I placed a couple of picture frames on the top of it anyway. 

Grocery stores often sell damaged goods at a lower cost as well. They only do this with products where the packaging has been damaged but nothing else. Canned goods that have been dropped and dented offer foods that are still good inside but that can on the shelf for regular price is going to get passed over time and time again. These items are generally found in one particular area of the store, often with other discounted items. 

You may not realize it but many discount retail stores such as Ross and TJ Max offer designer clothing that have some defects in them that make them not suitable to be sold at high priced retail stores. In most cases you can’t even see the damage to the clothing when you try them on. However, if you can get a designer jacket at ¼ of the original price just because the button holes are a little bit off center then by all means that is a tremendous bargain.

If you take the time to look at damaged goods in a different perspective, you will find they offer you significant savings. Since most retail stores offer customers a generous return policy it is very likely they have several items you are looking for that have been damaged while on display or returned by a customer due to damage. Taking advantage of these opportunities can help you get the items you want at a very good price. 

PPPPP

Word Count 578





