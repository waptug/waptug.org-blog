---
title: "Accept credit card"
date: 2020-04-12T18:56:46-08:00
description: "Credit_Cards Tips for Web Success"
featured_image: "/images/Credit_Cards.jpg"
tags: ["Credit Cards"]
---

Accept credit card
â€œWe accept credit cardsâ€

â€œWe accept credit cardsâ€ is a statement that you must have come across multiple times at various shops, grocery stores and other merchant outlets. This statement is generally accompanied by a few stickers (Visa/Master card etc).  Credit cards have transformed the businesses and our lives to a great extent. A few years back there were just a handful of shops that would accept credit cards but today you will find that most of the shops accept credit cards. In fact, some shops (like those belonging to a big retail chain) not only accept credit cards but also supply credit cards. These credit cards entitle you for rebates when you use them at any of the stores of that retail chain. 

With credit cards around, a lot of people have stopped carrying any cash with them or just carry a very small amount of cash with them. That means that any shop that doesnâ€™t accept credit cards is potentially losing customers. In fact, this is one reason why almost every merchant accepts credit cards. 

With the evolution of internet, credit card industry too took a new turn and up came ecommerce and e-shops. So, those stickers of â€œWe accept credit cardsâ€, moved on to the doors of internet shops. Thus came the era where almost every online-shop would accept credit cards (directly or indirectly). In fact, this was the premise on which the complete online-business industry was based. This is convenience at its best. 

Fraud is associated with almost every financial instrument. So there came fraudsters too, who too said that â€œWe accept credit cardsâ€. These fraudsters use a lot of techniques to commit credit card related fraud. Some of them disguise themselves as online merchants who accept credit cards as mode of payment (the actual motive being extraction of critical credit card details).  Others are people who work at merchant shops that accept credit cards. These fraudsters either clone the credit cards or just note critical information from them (and use that for online-shopping). Some other fraudsters lure innocent people into revealing credit card details in chat rooms. And then there are tech-savvy fraudsters who use computer programs/softwares/devices (called spyware) to spy on the people who use their credit cards for online payments. The spyware capture their credit card information and get it transmitted to the spy using internet.

So a lot of merchants and service providers do accept credit cards but keep in mind that the fraudsters too welcome/accept credit cards. This is something you surely need to be careful about.
 

