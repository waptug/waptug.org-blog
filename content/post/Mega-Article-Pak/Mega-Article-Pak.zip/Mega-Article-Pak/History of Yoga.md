---
title: "History of Yoga"
date: 2022-01-18T08:25:43-08:00
description: "yoga Tips for Web Success"
featured_image: "/images/yoga.jpg"
tags: ["yoga"]
---

History of Yoga

Yoga began in India 3,000 to 4,000 years ago. The word yoga comes from the Sanskrit language and means, to join or integrate, or simply union. Yoga started, as far as we know, as part of India's philosophical system, but not everyone practiced yoga, and it has never been a religion.

About 5 million people in the United States do some yoga. Dance and stretching exercise classes usually have parts and pieces that come directly from yoga. If you ever go to a physical therapist, he or she may give you therapeutic exercises that are yoga postures.

There are several types of yoga. The yoga you may have seen on TV or taught at your local Y or an adult education class is called hatha yoga, or physical yoga. Sometimes it's known as the yoga for health. You may also find yoga being taught in a hospital or medical setting. Many health professionals today feel yoga can be part of a treatment plan.

Hatha yoga has three parts: a series of exercises or movements called asana (poses or postures in English), breathing techniques of all kinds, and relaxation.

