---
title: "Making Taper Candles"
date: 2025-08-19T10:18:14-08:00
description: "Candle Making txt Tips for Web Success"
featured_image: "/images/Candle Making txt.jpg"
tags: ["Candle Making txt"]
---

Making Taper Candles

Taper candles add elegance to your dinner table. They are perfect for romantic evenings at home. You can make your own taper candles without much experience in candle making. The process of making taper candles involves and dipping rather than using molds or jars. Hand dipping takes some practice to get the hang of, but you will be a pro in no time. While you are practicing, you can melt that wax down again and again until you known the right way to form your taper candles. During practice, don’t add any color either to keep the costs low.

You will need to purchase a dipping can from a craft store or online to make taper candles correctly. A double boiler is to narrow to make this long candles. In addition, you will need a thermometer, wax, wick, dye for color, and fragrances to add scent if you desire. It is important you buy wick specially designed for taper candles. If you use pillar wick, your taper candles won’t burn properly. To make the best quality taper candles you will want to use paraffin wax. Beeswax can bend easier, especially on warm days. 

To melt the wax properly, use a large pot with a few inches of water for the dipping can to sit in. Never place the dipping can directly on the stove top as this is a safety issue. You may also expose your home to toxic fumes. While your wax is melting, work on your wicks. It is important you buy wick specially designed for taper candles. If you use pillar wick, your taper candles won’t burn properly. Cut the wick at least four inches longer than you want your candles to be. If you are making sets of taper candles, make sure each wick is cut the same exact length. This is easy to do by cutting one, then folding other pieces over and making a few more cuts. 

Once you wax has melted and at a temperature of between 150 and 165 degrees, you can start the dipping process. If you are going to add color or scent you will want to do it now. Move the dipping can to a flat, dry surface. If you are using a counter top, place a towel or cookie sheet under the dipping can. Take a wick and dip it into the hot wax. You will only be getting the wick covered the first few dips.

The process of dipping taper candles is easy, yet time consuming. You will get the best looking candles if you don’t try to rush the process. Each dip should be a quick in and out process. Don’t allow the candle to linger in the wax hoping it will absorb more. Instead, it will cause your taper candles to have a chunky texture rather than a smooth finish. As the wax starts to cool off take the time to stop dipping and heat it again. Some candle makers dip while they have another dipping can of wax melting on the stove. This way, once the wax they are working with cools they can switch. This keeps the process going if you are able to take advantage of it.

The number of times you will dip each candle depends on the width you want them. If you are making pairs, keep track of how many times you dip each one so they will match. As the wax begins to cool after each dip, you can dip it again. As the candle gets wider you will need to allow it to cool longer after each dip. You can also try dipping two at the same time – allowing one to cool while you dip the other of the set. Once the candle is the desired size and cools completely, cut the wick to ¼ inch of the top of the candle. 

Making hand dipped taper candles is a great project. The process is not difficult once you get the process of the dipping down. These candles are great center pieces and often used at weddings. You can make them any color you like for the occasion. There are many gorgeous taper candle holders on the market to add even more appeal to the lovely candles you created. 

PPPPP

Word Count 714

