---
title: "Five steps to a clean garage workshop"
date: 2020-08-24T19:53:58-08:00
description: "Garage Remodeling Tips for Web Success"
featured_image: "/images/Garage Remodeling.jpg"
tags: ["Garage Remodeling"]
---

Five steps to a clean garage workshop


You park your car in the driveway and you still have to work on your 
projects in the back yard. If you don’t use your garage for 
its designed purpose, why not turn it into a tidy workshop?
Here are five steps to turn your garage in a perfect small home 
workshop:

1)  Create your own workbench from an old door,s ome 
sawhorses or scrap wood.

2)  Mount a pegboard on the wall to store your tools. It would be 
a great idea to mount it above your workbench. Strategically 
place pegs according to the type of tools you will be placing on 
the board.  After hanging your tools, trace around them with a 
marker so you will know where each one goes.

3)  Use old jars for holding nails, nuts, bolts and screws.

4)  Make a storage box  for the rags because they tend to accumulate
in the working area.

5)  Use a small tackle box for transporting items such as screws and 
nails as you move around the shop.

(word count 174)

PPPPP

