---
title: "The First Bottle:  History of Scotch"
date: 2021-11-08T13:53:45-08:00
description: "Scotch Tips for Web Success"
featured_image: "/images/Scotch.jpg"
tags: ["Scotch"]
---
The First Bottle:  History of Scotch

Scotch is one of the most consumed alcoholic beverages of all time, after all it has been around for hundred of years however, little thought is usually given to the actual origin of this popular drink.  As the name suggests, Scotch was originally produced in Scotland by Friar John Cor.  After distillation was introduced by Scottish monks in 1494, fine scotch became a popular drink.  

To the dismay of Scotch and other whiskey drinkers, whiskey was first taxed in 1644.  This caused a rise in the number of what we would today call “bootleggers” who made and sold Scotch whiskey illegally.  Later in 1823, the Scottish Parliament made it easier for one to own a licensed distillery and harder for illegal whiskey stills to stay in business.   This began the modern production of Scotch whiskey.

Today, fine scotch whiskey production is much more technologically advanced:  It has to be in order to keep up with the demand for this popular drink.  However, you won’t find fine Scotch made here in the U.S, in order to adorn the name “Scotch” the whiskey must be distilled and matured in Scotland.  

Word count 195

PPPPP



