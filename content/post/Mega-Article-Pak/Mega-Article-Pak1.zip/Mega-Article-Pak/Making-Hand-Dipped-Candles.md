---
title: "Making Hand Dipped Candles"
date: 2021-11-27T04:33:34-08:00
description: "Candle Making txt Tips for Web Success"
featured_image: "/images/Candle Making txt.jpg"
tags: ["Candle Making txt"]
---

Making Hand Dipped Candles

Making candles is a great hobby or business endeavor. Once you get the hang of it, the process is quite simple. For those who have the basics down cold, consider experimenting with the art of making hand dipped candles. While these lovely creations take more time, they are stunning. You can use several colors on each candle giving it a unique color scheme. 

There are basic tools you will need to make hand dipped candles. Most of them you already use if you have experience in making candles. You will need a large amount of paraffin wax, wick, and a double boiler to melt it in. Other utensils include wooden spoons, bowls, and a good quality thermometer. The colors available for hand dipped candles are too many to name. These colors come in various forms including cakes, chips, powder, or liquid. If you choose to add scents to your hand dipped candles you need to make sure it is pure oil that does not have a water or alcohol base to it. 

You will prepare your wax for hand dipped candles that same as you do for regular candles. Let it continue to heat until it reaches a temperature of 160 degrees Fahrenheit. Once it does, turn the heat down very low to keep the wax in liquid form. Add the color to the wax, using a small amount at a time until your reach the color you want. Add a small amount of scent the mix at this time if you desire. Use scents moderately as you don’t want to have too powerful of a smell. Using too much fragrance can also result in the candle not burning properly. 

Next, cut the wick for your candles, keeping it just a bit longer than the candle length you want. If you are making sets of the candles, it is important to cut the wicks exactly the same length. You will want to dip the wicks into the candle wax making sure to coat it properly. This is how you will “build” your candle. After the wicks cool, dip them again. Each time you do, the candle will grow in size. If you want different areas of the candles to be different colors, you will be able to do so by simply having more than one color of wax ready to use. Once your candle is close to the desired thickness you want, shave it with a soft blade, giving the top a pointed look. Dip your candles a few more times to give them a smooth finish. 

Creating hand dipped candles is a great hobby or business venture. The process is time consuming, but the creations are beautiful. Learning to make hand dipped candles can be tricky. This is not a good type of candle for beginners to try to learn with. They will quickly become frustrated. To practice without wasting supplies, melt down the wax from the candles you are building and use it over and over again until you have the process perfected. 

To make particular designs on hand dipped candles, consider purchasing a book. Most will offer you great color photos with step by step directions for making each hand dipped candle. You will also be able to obtain great color charts for obtaining the best color for your candles. The internet is also a great place to get ideas for the colors of your hand dipped candles. 

PPPPP

Word Count 575

