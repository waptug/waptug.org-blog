---
title: "After school programs and discipline"
date: 2020-08-19T09:24:31-08:00
description: "After School Activities Tips for Web Success"
featured_image: "/images/After School Activities.jpg"
tags: ["After School Activities"]
---

After school programs and discipline

How important is discipline when it comes to after school programs? Since
most of the activities are recreational, does a program have to adhere to 
strict rules? Discipline is just as important here as it is in 
activities that pertain to the school. The child is sent to a program 
because you want him to learn more. Discipline in one form or the other is 
necessary to facilitate learning. 

Every program should begin by laying down the rules. The supervisor or 
teacher should explain each rule and can thus prevent future mishaps. 
Misbehavior should be addressed as and when it occurs. Deal with the 
problem in such a manner that it causes the least disruption. It is unwise 
to turn a blind eye to misbehavior because it catches on like fire, and 
soon you will have a bunch of unruly children on your hands. Besides, 
however much they resist it, children like to operate within the safety 
net of strict guidelines and rules. 

When a child misbehaves, it is mostly due to a craving for attention. A 
supervisor should observe the children and find out what the child wants. 
Talk to the child so that you can understand what he or she wants. 
Appropriate disciplinary measures should be taken if there are no apparent 
reasons for bad behavior. 

(word count 212)

PPPPP
