---
title: "La Jolla Sea Caves Tour"
date: 2025-12-04T16:31:22-08:00
description: "La Jolla California Tips for Web Success"
featured_image: "/images/La Jolla California.jpg"
tags: ["La Jolla California"]
---

La Jolla Sea Caves Tour

The most popular tour offered by Hike Bike Kayak of
San Diego is the kayak tour of the well known La
Jolla Sea Caves.  On this tour, you can witness the
abudant wildlife and amazing views of the La Jolla
Cove with your guide who will be an amateur naturalist.

Not only will you kayak up the caves at La Jolla
Shores, but you'll also witness dolphins swimming,
along with sea lions playing.  From your kayak, you
can see Mount Soledad to the east, the bluffs of
Torrey Pines State Reserve to the north, and La 
Jolla Cove to the south.

You can take the La Jolla Sea Caves tour every day
at 9:30 AM, 12:30 PM, and 2:30 PM.  Starting in
June, the tours are every half hour.  To make a 
reservation, all you need to do is call.

What to expect
On a typical day, you should be prepared to get
wet.  The tour launches into the waves from the end
of their street.  You meet at their shop, where you'll
check in, sign waivers, etc.  You'll also recieve
a lifejacket and paddle.  

You'll need to bring the following with you:
	-  Sunglasses with retainers
	-  Sunscreen
	-  A change of clothes
	-  Bathing suit
	-  Towel
	-  Sandals

The tour is very popular with tourists and locals
alike.  Hike Bike Kayak can accomodate age ranges
from 6 - 65.  They also have bike trailers and trail
a bikes for children that are 1 and older.  This 
way, anyone can take in the beauty and mystique 
this tour offers.

Cost and availability
The cost of the La Jolla Sea Caves tour is $50 per
person for singles, and $45 per person for tandem
kayaks or couples.  If you can go with someone else,
that would be easier choice.

(word count 300)

PPPPP
