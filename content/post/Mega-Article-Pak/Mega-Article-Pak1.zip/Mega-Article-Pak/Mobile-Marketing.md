---
title: "Mobile Marketing"
date: 2025-06-11T15:04:37-08:00
description: "TXT Tips for Web Success"
featured_image: "/images/TXT.jpg"
tags: ["TXT"]
---

Mobile Marketing

Mobile marketing can be classified into two types based on the technology involved. The more traditional form involves marketing on the move like moving billboards and road shows. The second type refers to marketing on a mobile phone like cell phone. Since the onset of millennium, mobile marketing though cell phone has become very popular. Short message service popularly known as SMS has made marketing by this method a lot easier.

There were some problems in the beginning as unwanted information was being sent to the people. Most of the SMS that were passed around was spam and it received negative media response in all parts of the world. This was because a sector of the advertisers bought list of mobile users and began sending them unsolicited messages. They were later stopped due to strict security measures and laws passed. Marketing industry recognized the potential of mobile marketing and utilized it to the full extent. The mobile service providers coded guidelines and laws. It then became a legal advertising channel. The Mobile Marketing Association and Interactive Advertising Bureau also have laid down guidelines for the proper functioning of mobile marketing. 

Mobile marketing has become popular in Asia and Europe as it is a novel idea and in Europe alone hundreds of millions of pounds have been investing in SMS advertising. Now SMS has become the most famous part of mobile marketing. Because of the popularity of short codes, SMSing has become a lot easier. This has created a new approach to reach out to potential customers. Now mobile short codes are looked upon as mobile domain name, by many of the brands around the world, when the customers message the brand at any occasion. 

In America, the first SMS short code campaign was started in 2002. SMS containing short codes are easier to send a message with complete information. Short codes are usually numbers that are assigned to mobile operators of a particular location, which they use for brand campaigning and other purposes. They are very small, like they contain only four to five words. These numbers are always under scrutiny by the service provider and each and every message is monitored to see that they do not go against the original service description. 

Like opt-in emails, customers have to opt for SMSes. This is the biggest criterion, which the advertiser has to follow in order to send a promotional SMS. Some of the mobile operators ask for double opt-in form from the receiver. At the same time opting out is made easy for the customer. When the customer wishes to terminate receiving messages, they have to send STOP word by SMS. All these guidelines have been laid by the Mobile Marketing Association consumer best practice guidelines and it’s a compulsion to follow those by all the marketers who wish to do mobile marketing in America.

Now, service providers have started to provide the option of sending SMS to email addresses. Other than this, other services provided are mobile games, mobile tones etc., which are used for promotional purposes. This has lead to the invention of MMS or Multi-media Message Service, through which short promotional videos and animations can be send. Bluetooth is another good technology. It started in 2003, and many companies in Europe have found it useful. When a message is send via Bluetooth, the receiver should accept request from the sender. So, sending messages by this method is legitimate. The message transfer speed is high and is also a free service as it is a radio-based technology. 

The method of sending SMS advertisement to mobile phone users based on their geographical location is known as Location based service. The customer is tracked via a GPS chip which is built-in the phone. Radiolocation signals from the nearest cell phone towers are used for this purpose.

Mobile marketing follows a very safe marketing strategy, as it is customer opted. The short message sent through this method is known as mobile originated or MO message. If the advertisement is done through a call, the call is known as mobile terminated or MT message. As there is a phenomenal increase in the number of mobile phone users, this kind of marketing is a sure hit.

PPPPP

Word Count 706

 


