---
title: "All about Paintball"
date: 2022-09-11T07:05:08-08:00
description: "Paint Ball Tips for Web Success"
featured_image: "/images/Paint Ball.jpg"
tags: ["Paint Ball"]
---

All about Paintball

War games have been around for a long time. These are used to prepare an army for battle or the beginning of a surprise attack. Since people are not able to use real guns in this game, Bob Gurnsey, Hayes Noel, Charles Gaines and nine others decided to play this game by using markers that were originally used to tag cattle and trees. This game originated in 1981.

Later on, markers were used to shoot paintballs at other players. The bullets used for each shot is a .68 caliber gelatin capsule which comes in various colors so that one team can distinguish the shots they fire from those of the opposition. Anyone that gets hit is out of the game. 

Paintball has evolved and through the years and  can be played in different ways. In one version of the game teams can one flag each and the other team must capture that flag in order to win. Another game has the same objective as the first will except there is only one flag that is situated in the center of the field and each team tries to be the first to capture the flag. The other way of winning (other than capturing the flag) would be to eliminate all of the players of the opposing team with paintball hits. 

The game can be played on a small scale which is called recreational paintball. This is the original way it was played in a wooded area and can be played in an area the size of a basketball court. 

If there are many people who want to play and the field is a large area the game is called a scenario. The largest scenario ever was in 2005 on a 700 acre parcel of land and with 3,000 participants. 

When a player who participates in a competition sanctioned by a governing body, that competition is called a tournament. Teams can be comprised of 3 to 10 players each. Rules during such events vary so people should check before entering the tournament.

For the safety of those who participate in these events, protective gear is required for each player. It consists of a helmet, chest pad, gloves, and knee and elbow pads. The guns used are only allowed to fire a maximum of 300 feet per second.      

Paintball is one game that is gaining ground in the sports world. According to a study done in 2005, it is ranked as the third most popular extreme game in the world. It is considered a safe sport as long as proper equipment is used and people comply with the rules. People who are interested can sign up at the local club and join in the fun. 



 


