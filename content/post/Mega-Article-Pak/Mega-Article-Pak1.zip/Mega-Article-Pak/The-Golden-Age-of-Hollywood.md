---
title: "The Golden Age of Hollywood"
date: 2020-08-13T02:33:28-08:00
description: "TXT Tips for Web Success"
featured_image: "/images/TXT.jpg"
tags: ["TXT"]
---

The Golden Age of Hollywood

According to many experts and people the golden era of Hollywood was during 1930's and 1940's when the industry was thriving. But many experts agree that although 30's brought in the commercial success but the actual golden age from artistic point of view began in 1920s itself when it drew talent from all over the world. Before this period Hollywood was just like any other film making locations but it was after First World War that it created a niche for itself in the world. The obvious reason was the magnitude of damage the European countries suffered in the World War and subsequent economic hardships faced by them thus affecting the film industry. Before the advent of Hollywood as a top destination Germany was the most popular destination known for its artistic excellence. America benefited from the fact that it suffered relatively less casualties and loss of property compared to European Nations. 

The popular names during the Golden Era were Clark Cable, Bette Davis, Charlie Chaplin, Bing Crosby, Spencer Tracy, Bob Hope, Ingrid, Judy Garland, Bergman, James Cagney, Jennifer Jones, Ronald Reagan, Elizabeth Taylor and Cary Gran, the list is endless. These actors became the house hold names throughout the country in 1930's and 1940's. The film industry during this era was so wealthy and powerful that studios like Paramount, MGM, Universal, 20th Century Fox and RKO kept adding more buildings to their studios. More than 7,000 films were released by these studios during the period of 1930's and 1940's. More than 75 million people flocked to see at least one film in a week during the peak years of Hollywood. 

Also during this era the nation saw threats due to Second World War. When soon this threat turned into reality the presidents of these studios took this as an opportunity to make films that would bond countrymen together during these tough and dreadful years. They made many patriotic movies involving actors like Betty Grable and Van Johnson. These movies in a way also helped the war efforts. Apart from the movies there were numerous short films and documentaries made. 

Some of the famous movies of the golden era include Memphis Belle: A Story of a Flying Fortress directed by William Wyler, Howard Hawks directed movies Sergeant York, To Have and Have Not. The commonality among all the movies of golden era was that almost all the movies ended on a happy note and patriotic ardor, which was liked by the people also. The movies made during the 1940's are referred to as "film noir" which in the literary context means "dark films". The movies were mostly pessimistic with tough male protagonist who was also a cynic and female protagonist would be attractive woman leading the males to a disastrous situation. Few examples of the Film Noir are Stranger on the Third Floor directed by Boris Ingster, High Sierra directed by Raoul Walsh, Shadow of a Doubt directed by Alfred Hitchcock and The Maltese Falcon directed by John Huston. 

The comedies were also popular during that era, the main feature of the comedies were duos forming during this period. Some of the famous duos of actors were Bob Hope and Bing Crosby famous for their movie Road to Singapore, Abbott and Costello, Spencer Tracy and Katharine Hepburn, and Dean Martin and Jerry Lewis. The movies that portrayed the lives of the westerns during the era were also popular with the people some of the examples being Fort Apache and She wore a Yellow Ribbon. But by the time these movies were released the downfall of the Hollywood has already begun due to the effects of the war, depression and arrival of television only to be not able to recover again. 

PPPPP

Word Count 625


