---
title: "Alcohol And Exercise"
date: 2021-09-02T20:40:54-08:00
description: "Exercise Tips for Web Success"
featured_image: "/images/Exercise.jpg"
tags: ["Exercise"]
---

Alcohol And Exercise

On Friday afternoon after you leave work, you probably
think about going out and having a few drinks with 
friends to relax and wind down.  Even though you 
may think you deserve to go out and have a few drinks,
there are some things that you should certainly keep
in mind.

Like any other day, tomorrow is going to be a day
for exercise, and since you are exercising on a 
regular basis, a few drinks of alcohol won't really
hurt anything, right?  Before you decide to rush out
to the local bar, there are a few things below that
you should think about before you make your choice
about going out to drink some alcohol.

Research has proven that even small amounts of 
alcohol with increase muscular endurance and the output
of strength, although these types of benefits are
very short lived.  After 20 minutes or so, the 
problems will begin to surface.  All of the negative
side effects associated with alcohol will easily
outweigh any possible benefits that it can have.  
No matter how you look at it, alcohol is a poison
that can really harm your body if you aren't careful.

The negative side of alcohol can reduce your 
strength, endurance, aerobic capability, recovery
time, ability to metabolize fat, and even your
muscle growth as well.  Alcohol will also have an
effect on your nervous system and brain.  If you
use it long term, you can cause severe deterioration
of your central nervous system.   Even with short
term use, nerve muscle interaction can be reduced 
which will result in a loss of strength.

Once alcohol reaches the blood cells, it can and
probably will damage them.  With alcohol users, 
inflammation of the muscle cells is a very common
thing.  Over periods of time, some of these cells
that have been damaged can die which will result
in less functional muscle contractions.  Drinking
alcohol will also leave you with more soreness of
your muscles after you exercise, which means that
it will take you a lot longer to recuperate.

Alcohol will also have many different effects on
your heart and circulatory system as well.  When
you drink any type of alcohol, you may begin to
see a reduction in your endurance capabilities.
Anytime you drink, your heat loss will increase,
due to the alcohol simulating your blood vessels
to dilate.  The loss in heat can cause your
muscles to become quite cold, therefore become
slower and weaker during your muscle contractions.

Drinking alcohol can also lead to digestive and
nutrition problems as well.  Alcohol cause a 
release of insulin that will increase the metabolism
of glycogen, which spares fat and makes the loss
of fat very hard.  Due to alcohol interfering 
with the absorption of several key nutrients, you
can also become anemic and deficient with B type
vitamins.  

Because your liver is the organ that detoxifies 
alcohol, the more you drink, the harder your liver
has to work.  The extra stress alcohol places on
your liver can cause serious damage and even
destroy some of your liver cells.

Since alcohol is diuretic, drinking large amounts
can put a lot of stress on your kidneys as well.
During diuretic action, the hormones are secreted.
This can lead to heightened water retention and no
one who exercises will want this to happen.

If you must drink alcohol, you should do it in
moderation and never drink before you exercise, as
this will impair your balance, coordination, and
also your judgement.  Think about your health and
how you exercise - and you may begin to look at
things from a whole new prospective.

PPPPP

(word count 602)
