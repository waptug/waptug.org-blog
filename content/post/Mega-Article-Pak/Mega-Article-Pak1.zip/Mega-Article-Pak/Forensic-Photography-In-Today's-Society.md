---
title: "Forensic Photography Used In Today’s Society"
date: 2021-12-15T00:21:33-08:00
description: "TXT Tips for Web Success"
featured_image: "/images/TXT.jpg"
tags: ["TXT"]
---

Forensic Photography Used In Today’s Society

As the crowd pushes closer around the crime scene and yellow tape gets strung around the place of murder, theft or other forms of violence, little white chalk people get drawn around a corpse and its contortions there from the sidelines with a bag and lighting equipment comes the often unsung hero of our Articles. He or she is an important part of every investigation, with their sharp eye for detail and the patience of Job in the hustle and bustle that never fails to happen as the newest crime gets tagged, bagged and labeled. 
I am talking about the Forensics Photographer. 

Aside from taking fingerprints, dusting the crime scene and bagging evidence carefully to bring to the forensics lab and later the Court room, Photos are an important part of every crime investigation and later as evidence in Court. 

Forensics Photography is a fantastic Tool to collect and catalog Data as well. Sometimes a sweep of the surroundings with the Camera logs in Images which would otherwise would have been overlooked or forgotten. The Person in the third row of the onlookers. That broken piece of glass in the shadow. Our busy Patrol Officer might have not noticed it, but our Camera Lens has picked it up. 

One of the most important things in Forensic Photography is the sharpness of the Image. It has to be sharp as a well honed blade. Any fuzziness, pixilation or shake and it is as useless to the Court and the Investigators as an Eagle with pinkeye. The entire case rests on Forensic Photography and any flaw however sight, could cost a case to be lost. 

Never, ever disturb the crime scene. The first round of photos has to be taken before anything has been touched, removed or altered. It is the freeze frame of the Crime Scene. The closest you will come to having been there during the crime. So make sure you plan the photo before you take it. Later if you must small adjustments, like the adding of a measuring tool to show distance is permissible, but not during the first go over. 

Make sure you get a complete set of shoots. Those should include a close-up, a mid range and a wide angle. The Angel is very important as well. If you use the wrong point of view you may easily undo the best shoot by misrepresenting the relationship of distance to the object etc. Remember, your photo has to show exactly what is set out before you. 

You need to record everything in writing. Mark out specific items, but never mark on the photo it-self. For that it is wise to use an overlay that you can remove as is needed. Transparency paper is used for that purpose. Make sure you lighting and exposure is set correctly. There are a lot of extremely good literature available that can teach you how to set your exposure for which light, background and scenario. This helps take the perfect pictures needed.

Lastly but not least. Photos can be messed up easily if your equipment is not in tip top shape. Make sure that your lens is clean at all times of dust. No smutches etc. I know it seems to be a topic that should not even have to be mentioned, but often it is the small things we overlook. After all the entire point of forensic photography is to capture those small seemingly mute points that are often overlooked. 

A suggest you make your-self  a check list and place even the most common sense items on your list. Batteries, Film, dust free equipment, tripod, removing the lens cap. You can think of it, write it down. You will be surprised sometimes how easily even the best professional forensic Photographer can make a simple mistake that could have been prevented by a check list. Remember the victim is counting on you too. 

PPPPP

Word Count 651

