---
title: "Make Retreating in a Paintball Game an Advantage"
date: 2020-02-17T14:33:39-08:00
description: "Paint Ball Tips for Web Success"
featured_image: "/images/Paint Ball.jpg"
tags: ["Paint Ball"]
---

Make Retreating in a Paintball Game an Advantage

To realize a common goal, teammates in a paintball game should take two important roles: one is to suppress and the other to invade.

Suppression is a way of distracting the opponent so that they fall short by not seeing the other team that is already starting to invade.  Suppression’s goal is not to get rid of enemies.  Control and concentration are needed to keep a team member from shooting. 

A team who uses suppression as a tactic should consist of three or more players.  Each member must know that their main objective is not to eliminate the other team’s members; although that could be true in other events.  Movements during this game should be accurate and targets must be aligned in order to make sure that the opposing team is unaware of the suppression.  A steady target and aiming of fire from the suppression players must not be in unison to leave the enemies with a puzzled feeling.

When making an assault, two or more of the paintball players who are making the suppression constantly distract one of the opponent’s players in order to disguise the players who are about to invade and attack the opposing team.  Suppression often conceals the other players and if done well, would eventually destroy the enemies who would have to retreat and could soon be eliminated when caught.

The other role that is played by the rest of the team is invading.  The players that are involved in the invasion must try very hard to hide themselves from the opponents while the suppression team is doing their job.  This requires patience, control, and discipline to keep from firing in order to save the position.  Make sure that with one shot severe damage to the opposing team is incurred rather than firing at one enemy player that did not realize the invader was there.

The invasion players target at least the majority of the opposing team’s players.  Once they are in position to capture the flag, they must fire with great power and with full force.  Since paintball guns are really loud, as soon as players start hitting target it must be accurate as there is no turning back.  Enemies will know where the guns are firing from so the invasion team will have to incur damage all at once to keep the opponent from counter attacking.  This will be shown by the amount of paint that is shot at the other team.

