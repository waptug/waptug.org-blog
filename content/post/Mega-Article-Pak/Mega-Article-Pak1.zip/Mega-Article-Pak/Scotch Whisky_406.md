---
title: "Scotch Whisky:  On top of the world."
date: 2019-04-06T19:33:54-08:00
description: "Scotch Tips for Web Success"
featured_image: "/images/Scotch.jpg"
tags: ["Scotch"]
---

Scotch Whisky:  On top of the world.

In terms of export, Scotch whisky amasses approximately 90% of all export sales combined in England and is a principle export commodity. This income is in great part foreign currency.  This trend has been followed since the turn of the 19-century as the value of overseas marketing was discovered.

Between 15-20% of all scotch whisky consumed in Scotland is first purchased in Britain.   Although the reason for this is unknown, they do not dwell on it since their Scotch seems to be more popular in other countries.  This is proven by the fact that scotch whisky is within the top five export earners and makes a considerable profit while making very large contributions to Britain’s foreign exchange.

Approximately 200 markets are in the exchange for Scotch whisky with the European Union being in the forefront vying for top spot with the United States, Japan and other Asian markets following suit. The European Union is accountable for at least 50% of all Scotch whisky sales with the other countries rounding up another 40% or so.

A nine-year sales projection is in reserve of scotch stock maturing or already matured.  In 1996 the stock of matured scotch was sitting at 2,741 million liters up a tenfold from 1945 at 247 million liters.  The stock was higher in 1939 at 374 million liters.  Obviously the Scotch whiskey market is predicted to grow based on the amount of maturing stock.  

It is a difficult trade dealing in stocks with a scotch manufacturer as they sit and wait on maturing product, they cannot accurately gather information on what the market years down the road will be for their product.  This is a commercial problem.  The most significant undertaking is the capital investment of maturing stock.

There is a very small portion of fine scotch that actually makes it out of Scotland and into other countries.  Matured whiskies as well as fresh fillings are an enticing profit grabber; however the time it takes for this product to turn over and give way to said profit makes this a risky endeavor. It is very hard to determine whether or not the products value will hold in the future.

In closing the value of these company’s finely distilled products is not likely to lose appeal any time soon, although one never knows what the future will bring.  For Scotch lovers, another drink is always in their futures.

406

PPPPP

