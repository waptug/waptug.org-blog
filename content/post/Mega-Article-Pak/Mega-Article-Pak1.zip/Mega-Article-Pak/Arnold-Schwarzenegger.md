---
title: "Arnold Schwarzenegger: A Short Bio"
date: 2025-07-26T03:07:17-08:00
description: "TXT Tips for Web Success"
featured_image: "/images/TXT.jpg"
tags: ["TXT"]
---

Arnold Schwarzenegger: A Short Bio

Arnold Alois Schwarzenegger born in Austria is a very versatile actor along with being a great bodybuilder and now a politician and the Governor of California. He was the second son of his parents. His father being a police officer taught him great values and brought him up in a very strict and disciplined environment.

Arnold had a great sports personality like his father. He had an ambition to be a body builder from his childhood and thus he began bodybuilding at the age of fifteen when he joined the soccer team of Austria. At the age of eighteen, in 1965 he joined the army and that's when he became serious about his body and started taking a strict diet. While in the army he took part in the Mr. Junior Europe contest in 1965 and won the competition. From then on there was no looking back for him. He won enormous number of professional titles after which he went to take part in the 1968 Mr. Universe competition. He won that one too and also became the youngest winner, at the age of twenty. He even won the Mr. Olympia titles consecutively for six years but lost to Sergio Oliva when he competed for the first time. He was given the nickname "The Austrian Oak" for his great body. He then left the competition saying that he wanted to give a chance to other talents too. George Butler made a documentary on Arnold's body building training named Pumping Iron. Besides body building being his ultimate dream, he entered Hollywood with his first movie "Hercules Goes to New York" in the year 1970. He won the Golden Globe Award for best new actor for his performance in the movie Stay Hungry, in 1976. His character in "Conan" movie required him to train vigorously and all the horse riding, sword training and running made him so strong that he required only eight weeks training for the competition. This time too, he won it. But it led to a controversy that the competition didn't support talent but popularity. 

Arnold's movies didn't click at the box office until he did "Terminator" in 1984, which was followed by other hits like "Twins", "Total Recall", "Commando" and "Kindergarten Cop". He started a construction firm whose profits were used to fund another small business of mail order of fitness material such as books and videocassettes. He even got a degree in business and international economics from the Wisconsin University to take his business to a further higher level. Within few years was living a luxurious life. He even wrote articles for body building magazines, Muscle & Fitness, and Flex. After being appointed as the governor he was promoted as the executive editor of both the magazines.

His first affair was with Barbara Outland Baker who was an English teacher but they split in 1974. After that Arnold dated Maria Shriver, niece of former president John F. Kennedy for eight years and then got married to her in 1986 and they live together ever since then and the couple have four children. In August 2003 he announced his decision to stand for the elections of Governor of California. He was elected on October 7, 2003 and he replaced Gary Davis with nearly 3.4 million votes in his favor. He was re-elected again in November 2006. He is a republican. He was ranked among the top hundred people who shaped the world by time. He continues to perform his duty as the Governor of California and is being lauded for bringing in many reforms. 

PPPPP

Word Count 601

