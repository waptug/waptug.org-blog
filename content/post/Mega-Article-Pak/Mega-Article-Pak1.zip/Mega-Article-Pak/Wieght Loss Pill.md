---
title: "What There is to Know About Diet Pills?"
date: 2020-05-18T20:38:29-08:00
description: "Weight Lloss Tips for Web Success"
featured_image: "/images/Weight Lloss.jpg"
tags: ["Weight Lloss"]
---

"What There is to Know About Diet Pills?"

According to manufacturers, diet pills use natural ingredients capable of prolonging life and containing alcohol used in medication or flavoring.  One thing’s for sure, never take diet pills as substitute for cutting calories without the doctor’s recommendation.  There are simple but important steps to be followed when taking diet pills:

1.Never crush diet pills to mix in drinks or soups.  Take it whole with a full glass of water.
2.Diet pills causes a person to urinate more frequently due to its diuretic effect.  This could lead to dehydration, thus, causing complications.  As a pre-caution, it is best to drink eight glasses of water everyday while on diet pills.
3.Take only the recommended dosage.  Taking more than required will not help you lose weight but increase the risk of side effects.
4.Heartbeat should be less than 86 beats per minute.  Stop taking the pills if it reaches 90 or higher that is why regular checking of pulse is a must.
5.Always follow the instructions set by the dietician and/or doctor and not only rely on what’s enclosed in the box.  Also diet pills will only work as expected if diet plan is being followed.
6.After three months, stop taking the diet pills.  Common diet phenylpropanolamine is safe to use only up to sixteen weeks.  Other studies show that it can cause health problems if taken under one month.

There are two kinds of diet pills; one is the prescription only diet pills and the over-the-counter diet pills.

Prescription Diet Pills - are drugs regulated by the Food and Drug Administration agency which side effects are monitored, maybe advertised and prescribed under certain dosages.  The most popular of these is Xenical, which is licensed for long-term use.  However, this too has it’s own side effects, diarrhea, oily and unexpected fecal discharge are just some.  Therefore, users are advised to take a low fat diet plan.

While Over-the-Counter Diet Pills are categorized as food substitute and are unregulated.  Beware that these diet pills are not Federal authorities tested and may cause serious side effects up to and including death.

Aside from a dietician, local pharmacists can also help in determining the pills that are safe and not for each person’s case.  Just be extra careful about the so-called “natural” or “organic” ingredients.  Not everything that comes from a natural source is safe.  One example is Ma Huang, which is a botanical source of ephedrine known as a stimulant and being studied for potential side effects.

Those who have or have a family history of prostate problems, thyroid disease, mental illness, high blood pressure, and heart problems should avoid taking diet supplements.  The same applies to those who’ve had seizures or strokes.  If someone is taking cold medicines, especially those with decongestants, diet pills should not be taken.  Whether it be a prescription or an over-the-counter diet pill, the dangers are unvarying with other similar drugs which controls the brain to reduce appetite and includes chest pains, hair fall, fever, depression, and even impotence.

And as a general rule, don’t ever try to take diet drugs if pregnancy is suspected.  Persons that are allergic to sulfites and tartrazine should also avoid taking diet pills.  And those who are under 18 years or over 60 years of age should consult their doctor first prior to taking any dietary drugs, especially if they rely on over-the-counter stimulants used as a replacement for increase exercise.









