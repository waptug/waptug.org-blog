---
title: "Patient Abuse by Nursing Assistants"
date: 2021-01-01T09:22:04-08:00
description: "Text Tips for Web Success"
featured_image: "/images/Text.jpg"
tags: ["Text"]
---

Patient Abuse by Nursing Assistants

We have all heard horror stories of patient abuse by Nursing Assistants. This takes shape in many forms including sexual abuse, physical abuse, emotional abuse, and theft. Most medical facilities Nationwide are taking precautions against such abuse occurring, including completing background checks. In some states, you can’t work as a Nursing Assistant if you have any charges relating to domestic violence, harassment, or drunk driving because it is possible such behaviors can escalate in the work environment.

Many organizations complain that Nursing Assistants aren’t properly looked into because the demand is so great in the industry. As a result, some employers are lowering the background check expectations. However, many states are holding the employer responsible when such abuse occurs, so this will likely help to curb that process.

Sexual abuse charges by Nursing Assistants are taken very seriously. Such sexual abuse reports include allegations of inappropriate touching and sexual intercourse. It is most commonly found to take place with male Nursing Assistants with those they are responsible for bathing. It is the responsibility of Nurses to routinely make a surprise visit into the area where a Nursing Assistant is alone with a patient. This will help convey the message that their endeavors may be interrupted and caught. 

Physical abuse by Nursing Assistants is often hard to prove unless it has been witnessed or bruises appear. Often this type of abuse is conducted by Nursing Assistants who are not satisfied with their job. They are easily upset, frustrated, and overwhelmed. Some abuse their patients as a method of teaching them that they think some of their behaviors are inappropriate. For example, some patients have reported being hit for soiling their clothes and bedding. This often goes unreported in elderly populations as they become very afraid. 

Verbal abuse is one of the most common types of abuse by Nursing Assistants. It can be simple teasing, belittling, or threats. Often this type of behavior stems out of control issues and the desire to have a more important job. 

Theft is the number one reported type of abuse by Nursing Assistants. In can include cash, food, jewelry, and even dietary supplements. In medical facilities, such theft can be hard to prove who did it because the patient comes into contact with so many individuals who work in the facility.

While most Nursing Assistants do their job with as much energy and work ethic as humanly possible, there are those who give the entire profession a bad name. It is sad when you think about it – when is the last time a Nursing Assistant who did a good job made National headlines? Yet let one fall out of line, and you will hear it on the TV, radio, and the internet continuously. 

The Nursing Assistant profession can be very difficult. It takes a very particular type of individual to be able to meet the requirements. Employers have a responsibility to protect all the patients. This requires money and time to be spent on extensive background checks and training. It also requires workshops and ongoing training for all staff members. Everyone should know signs of abuse to be watching for and how to report them. Abuse by Nursing Assistants will be prosecuted by law. Anyone going into the profession needs to be made very aware of that. 

PPPPP

Word Count 556



