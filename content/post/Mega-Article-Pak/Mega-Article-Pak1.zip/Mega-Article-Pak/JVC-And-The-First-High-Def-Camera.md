---
title: "JVC And The First High Def Camera"
date: 2020-08-01T03:27:05-08:00
description: "High Definition Video Cameras Tips for Web Success"
featured_image: "/images/High Definition Video Cameras.jpg"
tags: ["High Definition Video Cameras"]
---

JVC And The First High Def Camera

The amazing company of JVC (Victor Company of Japan)
released the first high definition video camera for
consumers back in 2003.  The GR-HD1 high def camera
was the first digital video camera in the world to
record and play back high definition images.

By utilizing a newly developed 1/3 inch type 1.18
million pixel progressive scan CCD and JVC type
processing, the new camera records and plays back
750/30p digital high definition and 525p progressive
wide screen images to mini DV tape.  

Features
The GR-HD1 is was the first digital video camera in
the world to record and play back high definition
video and images.  The GR-HD1 records digital images
to mini DV tapes using MPEG 2 compression, recording
and playing back digital high definition images
while still maintaining conventional 525i DV
standard recording times.

The GR-HD1 also comes with an optical 10X zoom lens
and a built in optical image stabilizer.  It also
uses a newly developed 1/3 inch type 1.18 million
pixel (1.14 million effective pixels) progressive
scan CCD.  Due to the JVC original signal 
processing circuitry and driving system, it can
record muti format high quality images.

There are three recording modes; HD mode, SD
mode, and DV mode that are based according to 
the camera operators requirements.  

The HD mode records 750/30p digital high definition
images, SD mode 525p progressive wide images, DV
mode at the conventional 525i DV standard.  This
way, camera users can freely choose among the 3
modes according to their specific requirements.

Even though it was the first high definition
video camera to release to consumers, the GR-HD1
is still a very impressive camera.  It has a 
slew of other features, which are sure to please
camera lovers everywhere.  

(word count 287)

PPPPP
