---
title: "Canning Jar Candles"
date: 2024-06-11T08:18:41-08:00
description: "Candle Making txt Tips for Web Success"
featured_image: "/images/Candle Making txt.jpg"
tags: ["Candle Making txt"]
---

Canning Jar Candles

We have all seen those beautiful canning jar candles with the pretty ribbon and potpourri. It is very easy to make your own canning jar candles with just a few inexpensive items that you can get from your local craft store or online. You will need wide mouth canning jars, ribbon, potpourri, votive candles with holders, and a hot glue gun. Make your own canning jar candles to add charm to the dinner table as a center piece or gift them to family and friends for gifts. 

To start, fill the jar with potpourri. If you desire, add some extras such as dried apples or cinnamon sticks. Fill the jar full enough that when you set the candle holder on top it is even with the top of the jar. Place the candle in the holder once you have got the fit right. Next, glue the ribbon around the top mouth area of the canning jar. You can further personalize your canning jar candles by gluing on decorations. Canning jar candles are a great idea for Mother’s Day or crafts for young children to take home. 

Canning jar candles are great for all Holidays as well. Add pumpkin cut outs for Halloween, little bunnies for Easter, and Christmas trees or small ornaments for Christmas. Canning candle jars make excellent fundraisers or items to sell at the next craft show. The internet offers many great canning jar candle décor ideas, especially for the holidays. Your local craft stores and the internet are great places to get canning jar candle ideas. Those of you who are more creative will have no trouble designing your own. 

McCall’s canning jar candles are already made. They come with wonderful labels that are very rustic looking. This candle collection comes in many wonderful fragrances with a zinc wick. These canning jar candles come in two sizes, the 5 ounce that burns for about 30-35 hours and the 16 ounce burns for 110-115 hours. The small candles retail for $13.63 and the larger ones are $24.63. While these are great candles as well, you will miss out on the experience of candle making if you choose to purchase them. You will also be able to make several of your own for the cost of one McCall’s canning jar candle. 

To save even more money when making canning jar candles, consider making your own votives. You can do this easily in you home. You will need paraffin wax, wick, and candle holders. You can choose to use dye for colored votives or scents to add a wonderful smell to the candles. It is very easy to melt the wax and add in whatever you want to make the color and smell you desire. Then simply pour the hot wax into the candle holders. To save even more, shop at thrift stores and yard sales for canning jars and votive holders at a very low price. 

Canning jar candles are very easy to make and they are very beautiful. You can make them in very little time and young children will be able to do this with ease as long as you help them with the glue gun. Make canning jar candles for you own personal use or as gifts. These cute candles are very inexpensive to make and they last a very long time, giving a delicious aroma. 

PPPPP

Word Count 563




