---
title: "THE COLLIE DOG."
date: 2023-09-13T17:37:29-08:00
description: "Dogs Tips for Web Success"
featured_image: "/images/Dogs.jpg"
tags: ["Dogs"]
---

THE COLLIE DOG. 

The Collie dog makes an excellent sporting dog, and can be taught to do the work of the Pointer and the Setter, as well as that of the Water Spaniel and the Retriever. He can be trained to perform the duties of other breeds.  He is clever at hunting, having an excellent nose, is a good vermin-killer, and a most faithful watch, guard, and companion. 

Little is known with certainty of the origin of the Collie, but his cunning and his outward appearance would seem to indicate a relationship with the wild dog. Buffon was of opinion that he was the true dog of nature, the stock and model of the whole canine species. He considered the Sheepdog superior in instinct and intelligence to all other breeds, and that, with a character in which education has comparatively little share, he is the only animal born perfectly trained for the service of man. 

At the shows this type of dog is invariably at the top of the class. He is considered the most tractable, and is certainly the most agile. Second to this type in favour is the smooth-coated variety, a very hard, useful dog, well adapted for hill work and usually very fleet of foot. He is not so sweet in temper as the black and white, and is slow to make friends. There is not a more  graceful and physically beautiful dog to be seen than the show Collie of the present period. Produced from the old working type, he is now practically a distinct breed.  

The skull should be flat, moderately wide between the ears, and gradually tapering towards the eyes. There should only be a slight depression at stop. The width of skull necessarily depends upon combined length of skull and muzzle; and the whole must be considered in connection with the size of the dog. The cheek should not be full or prominent.  

The muzzle should be of fair length, tapering to the nose, and must not show weakness or be snipy or lippy. Whatever the colour of the dog may be, the nose must be black. The teeth should be of good size, sound and level; very slight unevenness is permissible. The jaws Clean cut and powerful. The eyes are a very important feature, and give expression to the dog; they should be of medium size, set somewhat obliquely, of almond shape, and of a brown colour except in the case of merles, when the eyes are frequently (one or both) blue and white or china; expression full of intelligence, with a quick alert look when listening. The ears should be small and moderately wide at the base, and placed not too close together but on the top of the skull and not on the side of the head. When in repose they should be usually carried thrown back, but when on the alert brought forward and carried semi-erect, with tips slightly drooping in attitude of listening.  

The neck should be muscular, powerful and of fair length, and somewhat arched.  The body should be strong, with well sprung ribs, chest deep, fairly broad behind the shoulders, which should be sloped, loins very powerful. The dog should be straight in front. The fore-legs should be straight and muscular, neither in nor out at elbows, with a fair amount of bone; the forearm somewhat fleshy, the pasterns showing flexibility without weakness. The hind-legs should be muscular at the thighs, clean and sinewy below the hocks, with well bent stifles. The feet should be oval in shape, soles well padded, and the toes arched and close together.  

In general character he is a lithe active dog, his deep chest showing lung power, his neck strength, his sloping shoulders and well bent hocks indicating speed, and his expression high intelligence. He should be a fair length on the leg, giving him more of a racy than a cloddy appearance. In a few words, a Collie should show endurance, activity, and intelligence, with free and true action. In height dogs should be 22 ins. to 24 ins. at the shoulders, bitches 20 ins. to 22 ins. The weight for dogs is 45 to 65 lbs., bitches 40 to 55 lbs. The smooth collie only differs from the rough in its coat, which should be hard, dense and quite smooth.  
